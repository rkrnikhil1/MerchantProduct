package org.jsp.merchantproduct.controller;

import java.util.Scanner;

import org.jsp.merchantproduct.dao.MerchantDao;
import org.jsp.merchantproduct.dao.ProductDao;
import org.jsp.merchantproduct.dto.Merchant;
import org.jsp.merchantproduct.dto.Product;


public class MerchantProductController {
  
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MerchantDao mDao = new MerchantDao();
		ProductDao pDao = new ProductDao();
		
		System.out.println("1.Save Merchant");
		System.out.println("2.Update Merchant");
		System.out.println("3.Add Product");
		System.out.println("4.Verify Merchant By Phone and password");
		System.out.println("5.View Products By Merchant Id");
		System.out.println("6.View Products By Brand");
		System.out.println("7.View Products By Category");
		System.out.println("8.Update Product");
		
		int choice =sc.nextInt();
		 
		switch(choice)
		{
		case 1:
		{
			System.out.println("Enter the name, phone, email, password");
			String name=sc.next();
			long phone=sc.nextLong();
			String email=sc.next();
			String password=sc.next();
			
			Merchant m=new Merchant();
			m.setName(name);
			m.setPhone(phone);
			m.setEmail(email);
			m.setPassword(password);
			 mDao.saveMerchant(m);
			 System.out.println("merchant registered with id: "+m.getId());
			 break;
		}
		case 2:{
			System.out.println("Enter the id, name, phone, email, password");
			int id=sc.nextInt();
			String name=sc.next();
			long phone=sc.nextLong();
			String email=sc.next();
			String password=sc.next();
			
			Merchant m=new Merchant();
			m.setId(id);
			m.setName(name);
			m.setPhone(phone);
			m.setEmail(email);
			m.setPassword(password);
			 mDao.updateMerchant(m);
			 System.out.println("merchant updated with id: "+m.getId());
			 break;
		}
		case 3:
		{
			System.out.println("Enter the id, name, brand, category, cost, description");
			int id=sc.nextInt();
			String name=sc.next();
			String brand=sc.next();
			String category=sc.next();
			double cost =sc.nextDouble();
			String description=sc.next();
			
			Product p=new Product();
			p.setId(id);
			p.setName(name);
			p.setBrand(brand);
			p.setCategory(category);
			p.setCost(cost);
			p.setDescription(description);
			 pDao.addProduct(p, id);
			 System.out.println("your product is added!!!");
			 break;
		}
		}
	}

}
