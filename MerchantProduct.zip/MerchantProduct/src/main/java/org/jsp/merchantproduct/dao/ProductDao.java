package org.jsp.merchantproduct.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.jsp.merchantproduct.dto.Merchant;
import org.jsp.merchantproduct.dto.Product;

public class ProductDao {
 EntityManager manager=Persistence.createEntityManagerFactory("dev").createEntityManager();
 EntityTransaction transaction=manager.getTransaction();
 
 public Product addProduct(Product product,int merchant_id)
 {
	 Merchant m=manager.find(Merchant.class, merchant_id);
			 if(m!=null)
			 {
				 product.setMerchant(m);
				 m.getProduct().add(product);
				 manager.persist(product);
				 transaction.begin();
				 transaction.commit();
				 return product;
			 }
	return null;
 }
 public Product updateProduct(Product product,int merchant_id)
 {
	 Merchant m=manager.find(Merchant.class, merchant_id);
			 if(m!=null)
			 {
				 product.setMerchant(m);
				
				 manager.merge(product);
				 transaction.begin();
				 transaction.commit();
				 return product;
			 }
	return null;
 }
 public List<Product> findProduct(int merchant_id)
 {
	 String qry="select p from product p where p.merchant_id=?1";
	 Query q=manager.createQuery(qry);
	 q.setParameter(1, merchant_id);
	 try {
		 return q.getResultList();
	 }catch(NoResultException e) {
	 
	return null;
	 } 
 }
 public List<Product> findProduct(String brand)
 {
	 String qry="select p from product p where p.brand=?1";
	 Query q=manager.createQuery(qry);
	 q.setParameter(1, brand);
	 try {
		 return q.getResultList();
	 }catch(NoResultException e) {
	 
	return null;
	 } 
 }
 public List<Product> findProductByCategory(String category)
 {
	 String qry="select p from product p where p.category=?1";
	 Query q=manager.createQuery(qry);
	 q.setParameter(1, category);
	 try {
		 return q.getResultList();
	 }catch(NoResultException e) {
	 
	return null;
	 } 
 }
}
