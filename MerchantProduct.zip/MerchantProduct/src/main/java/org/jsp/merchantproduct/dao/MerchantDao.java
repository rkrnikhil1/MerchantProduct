package org.jsp.merchantproduct.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.jsp.merchantproduct.dto.Merchant;

public class MerchantDao {
  
    EntityManager manager =Persistence.createEntityManagerFactory("dev").createEntityManager();
    EntityTransaction transaction=manager.getTransaction();
    
    public Merchant saveMerchant(Merchant merchant)
    {
    	manager.persist(merchant);
    	transaction.begin();
    	transaction.commit();
		return merchant;
    }
    public Merchant updateMerchant(Merchant merchant) {
    	manager.merge(merchant);
    	transaction.begin();
    	transaction.commit();
		return merchant;
    }
    public Merchant findMerchant(long phone,String password)
    {
    	String qry="select m from merchant m where m.phone=?1 and m.password=?2";
       Query q=manager.createQuery(qry);
       q.setParameter(1, phone);
       q.setParameter(2, password);
       try {
    	   return (Merchant) q.getSingleResult();
       }catch(NoResultException e) {
    	   return null;
       }
    }
         
    
    
    
    
    
    
    
    
    
    
    
    
}
